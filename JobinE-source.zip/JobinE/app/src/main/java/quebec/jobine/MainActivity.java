package quebec.jobine;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_NOTIF = 1002;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(this), "JobinEAndroid");
        webView.loadUrl("file:///android_asset/index.html");
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            NotificationChannel ch = new NotificationChannel("proximity", "Opportunités à proximité", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Notifications JobinE lorsqu'une occasion compatible est près de vous.");
            nm.createNotificationChannel(ch);
        }
    }

    private void requestLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        sendLocation();
    }

    private void sendLocation() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String provider : lm.getProviders(true)) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
                Location l = lm.getLastKnownLocation(provider);
                if (l != null && (best == null || l.getAccuracy() < best.getAccuracy())) best = l;
            }
            if (best != null) {
                double lat = Math.round(best.getLatitude() * 100.0) / 100.0;
                double lng = Math.round(best.getLongitude() * 100.0) / 100.0;
                final String js = "window.JobinE && JobinE.onLocation(" + lat + "," + lng + ");";
                webView.post(() -> webView.evaluateJavascript(js, null));
            } else {
                webView.post(() -> webView.evaluateJavascript("window.JobinE && JobinE.onLocationUnavailable();", null));
            }
        } catch (Exception e) {
            webView.post(() -> webView.evaluateJavascript("window.JobinE && JobinE.onLocationUnavailable();", null));
        }
    }

    private void notifyWhistle() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        android.app.Notification.Builder b = new android.app.Notification.Builder(this, "proximity")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("JobinE • Un employeur vous siffle 👋")
                .setContentText("Une entreprise compatible cherche quelqu’un dans votre secteur.")
                .setAutoCancel(true)
                .setContentIntent(pi);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(3601, b.build());
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) sendLocation();
        if (requestCode == REQ_NOTIF) notifyWhistle();
    }

    public class Bridge {
        Context ctx;
        Bridge(Context c) { ctx = c; }
        @JavascriptInterface public void requestLocation() { runOnUiThread(() -> MainActivity.this.requestLocation()); }
        @JavascriptInterface public void demoWhistle() { runOnUiThread(() -> MainActivity.this.notifyWhistle()); }
        @JavascriptInterface public String appVersion() { return "0.1.0"; }
    }
}
