# JobinE

Prototype Android natif (WebView local) pour une application québécoise de recrutement gamifiée.

Fonctions MVP :
- carte visuelle des occasions à proximité;
- permission de localisation avec coordonnées arrondies côté interface;
- modes candidat / employeur;
- « sifflement » de proximité avec notification Android locale;
- fil professionnel;
- offres et candidatures rapides simulées;
- progression ludique avec haricot, points et défis;
- paramètres de confidentialité.

Le prototype fonctionne hors ligne pour l'interface. Les données d'emplois sont de démonstration; un backend sera requis pour les comptes, offres réelles, messagerie et géorequêtes.
